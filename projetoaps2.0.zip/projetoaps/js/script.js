$(function () {

    $('.menu-mobile, .nav-close').click(function (e) {
        e.preventDefault();
        $('.nav').toggleClass('active');
    });

    //Fixar header-topo
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {

            $('.header-topo').addClass('fixed');
        }

        else {
            $('.header-topo').removeClass('fixed');
        }
    });
});